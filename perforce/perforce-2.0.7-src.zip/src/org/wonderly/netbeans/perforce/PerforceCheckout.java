package org.wonderly.netbeans.perforce;

public final class PerforceCheckout extends PerforceCommand {
   public PerforceCheckout() {
       super( "edit", "CTL_PerforceCheckout", "checkout.gif" );
   }
}