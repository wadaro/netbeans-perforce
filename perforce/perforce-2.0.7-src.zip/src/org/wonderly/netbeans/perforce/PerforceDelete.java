package org.wonderly.netbeans.perforce;

public final class PerforceDelete extends PerforceCommand {
   public PerforceDelete() {
       super( "delete", "CTL_PerforceDelete", "remove.gif");
   }
}